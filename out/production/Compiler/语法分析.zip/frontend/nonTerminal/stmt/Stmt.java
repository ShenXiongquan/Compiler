package frontend.nonTerminal.stmt;


public abstract class Stmt {
    public abstract void visit();
}


